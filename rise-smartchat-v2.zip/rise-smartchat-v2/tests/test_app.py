import hashlib, hmac, os, time
from pathlib import Path
from fastapi.testclient import TestClient

os.environ.setdefault('RISE_ADMIN_PASSWORD','test-only-password-not-for-deployment')
os.environ.setdefault('RISE_SESSION_SECRET','test-secret-unique-value-longer-than-32-chars')
os.environ.setdefault('CHATWOOT_ACCOUNT_ID','9')
os.environ.setdefault('CHATWOOT_WEBHOOK_SECRET','local-test-secret')
os.environ.setdefault('RISE_DATA_DIR','/tmp/rise-smartchat-pytests')
from main import app


def test_login_and_diagnostics():
    with TestClient(app) as client:
        r=client.post('/api/login',json={'password':os.environ['RISE_ADMIN_PASSWORD']})
        assert r.status_code==200
        csrf=r.json()['csrf']
        status=client.get('/api/chatwoot/status')
        assert status.status_code==200
        assert status.json()['automatic_sending'] is False
        assert client.post('/api/chatwoot/threads/1/pause',json={'paused':True}).status_code==403
        good=client.post('/api/chatwoot/threads/1/pause',headers={'x-rise-csrf':csrf},json={'paused':True})
        assert good.status_code==200
        assert good.json()['paused'] is True


def test_webhook_signed_deduplicated_and_wrong_account():
    import json
    body=json.dumps({'event':'message_created','account':{'id':9},'conversation':{'id':42},'sender':{'name':'Visitante Teste'},'content':'Olá','message_type':'incoming'}).encode()
    now=str(int(time.time()))
    signature='sha256='+hmac.new(b'local-test-secret',now.encode()+b'.'+body,hashlib.sha256).hexdigest()
    headers={'x-chatwoot-signature':signature,'x-chatwoot-timestamp':now,'x-chatwoot-delivery':'unique-test-event-2026','content-type':'application/json'}
    with TestClient(app) as client:
        first=client.post('/api/webhooks/chatwoot',content=body,headers=headers)
        assert first.status_code==200,first.text
        second=client.post('/api/webhooks/chatwoot',content=body,headers=headers)
        assert second.json().get('duplicate') is True
        bad=client.post('/api/webhooks/chatwoot',content=body.replace(b'Ola',b'Muda'),headers={**headers,'x-chatwoot-signature':'sha256='+'0'*64})
        assert bad.status_code==401
