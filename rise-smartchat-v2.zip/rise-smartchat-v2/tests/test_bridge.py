import hashlib, hmac, time
from chatwoot_bridge import verify_webhook

def headers(body, secret, now, delivery='test-1'):
    stamp=str(now)
    digest=hmac.new(secret.encode(), stamp.encode()+b'.'+body,hashlib.sha256).hexdigest()
    return {'x-chatwoot-signature':'sha256='+digest,'x-chatwoot-timestamp':stamp,'x-chatwoot-delivery':delivery}

def test_signed_event():
    now=int(time.time());body=b'{"event":"message_created"}'
    assert verify_webhook(body,headers(body,'secret',now),'secret',now=now)

def test_reject_tampering():
    now=int(time.time());body=b'{"event":"message_created"}'
    assert not verify_webhook(body+b'!',headers(body,'secret',now),'secret',now=now)

def test_reject_stale():
    now=int(time.time());body=b'{}'
    assert not verify_webhook(body,headers(body,'secret',now-400),'secret',now=now)

def test_reject_no_secret():
    now=int(time.time());body=b'{}'
    assert not verify_webhook(body,headers(body,'secret',now),'',now=now)
